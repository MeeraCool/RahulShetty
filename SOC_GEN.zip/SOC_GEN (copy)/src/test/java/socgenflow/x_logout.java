package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;

@TestMethodOrder(OrderAnnotation.class)
public class x_logout extends BaseTest {

	@BeforeAll
	public static void begining() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		//open("http://10.32.2.51:8483/SocieteGenerale/");
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}
	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")


	public void Start() throws IOException, InterruptedException {

		Thread.sleep(5000);

		$(By.id(soclogininputbox)).waitUntil(visible, 30000).sendKeys(socloginval);
		$(By.id(socpasswordinputbox)).waitUntil(visible, 30000).sendKeys(socpasswordval);
		$(By.id(socloginbutton)).shouldBe(visible).click();

		Thread.sleep(5000);
		Selenide.screenshot("HomeScreen");
		System.out.println("123");
	}
	@Test
	@Order(2)
	public void Logout_popup() throws InterruptedException, AWTException, IOException {//imp
		Thread.sleep(5000);
		$(By.id(logouticon)).shouldBe(visible).click();
		 //  Assertions.assertTrue($(By.id("PRIREM__acc_pricing__el_img_1")).is(visible));
		Thread.sleep(3000);
		String logouttextvalueActual = $(By.xpath(logouttextvalue)).waitUntil(visible, 30000).getText();
		String logouttextvalueexpectActualExpected = logouttextvalueexpect;
		Assertions.assertTrue(logouttextvalueexpectActualExpected.equals((logouttextvalueActual)));
		$(By.xpath(logoutok)).shouldBe(visible).click();
	}@Test
	@Order(3)
	public void Single_Document_myrequest_search_screen() throws InterruptedException, AWTException, IOException {
		// String successtemplateActual =
		// $(By.id(Chooseyouraccounttype)).waitUntil(visible, 30000).getText();
		// String successtemplateActualExpected = Chooseyouraccounttypeval;
		// Assertions.assertTrue(successtemplateActualExpected.contains((AccounttypeActual)));
		Thread.sleep(2000);
		$(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
	     Assertions.assertTrue($(By.id("PRIREM__acc_pricing__el_img_1")).is(visible));
	     Thread.sleep(2000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
	     Thread.sleep(2000);
	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
			String AccountnumberActualExpected = "12345678";
			Assertions.assertTrue(AccountnumberActualExpected.contains((AccountnumberActual)));
		Thread.sleep(4000);
		$(By.id(All)).waitUntil(visible, 30000).click();
		//$(By.id(swiftnet)).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		Thread.sleep(3000);
		$(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
	     Assertions.assertTrue($(By.id("PRIREM__acc_pricing__el_img_1")).is(visible));
	     Thread.sleep(2000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
	     String AccountnumberActual1 = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
			String AccountnumberActualExpected1 = "12345678";
			Assertions.assertTrue(AccountnumberActualExpected1.equals((AccountnumberActual1)));
	}
	@Test
	@Order(4)
	public void Single_Document_pricing_approval_search_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(2000);
		 $(By.xpath(pricingmain)).waitUntil(visible, 30000).click();
		 Thread.sleep(3000);
		$(By.xpath(adminpendingapprovalmain)).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		//label[@id='PRIREM__pricing__el_rdo_1_option_pendingReq_span_']
		 //PRIREM__acc_pricing__el_inp_1
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).click();
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("123456789");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//img[@id='PRIREM__pricing__el_img_1']
		  Thread.sleep(3000);
	  //    Assertions.assertTrue($(By.xpath("//img[@id='PRIREM__pricing__el_img_1']")).waitUntil(visible, 30000).is(visible));
//		  String imagetextActual = $(By.xpath(norecordsfoundtext)).waitUntil(visible, 40000).getText();
//		  Thread.sleep(2000);
//			String imagetextActualExpected = "No Records Found!";
//			Assertions.assertTrue(imagetextActualExpected.equals((imagetextActual)));
	     Thread.sleep(2000);
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).clear();
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("12345678");
//	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
//		    String Accountnumber1Actual = $(By.id(Accountnumbervalue1)).waitUntil(visible, 30000).getText();
//			String Accountnumber1ActualExpected = "12345678";
//			Assertions.assertTrue(Accountnumber1ActualExpected.equals((Accountnumber1Actual)));
			$(By.id(myrequestsforwardicon1)).waitUntil(visible, 30000).click();
		    // $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		     System.out.println("awe");
		 
	}
	@Test
	@Order(5)
	public void Single_Document_template_approval_screen_search_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		 //PRIREM__acc_pricing__el_inp_1
		 $(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
	    // Assertions.assertTrue($(By.id("PRIREM__acc_pricing__el_img_1")).is(visible));
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
//	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		$(By.id(All)).waitUntil(visible, 30000).click();
		$(By.id(swiftnet)).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		$(By.id(Approvebutton)).waitUntil(visible, 30000).click();
//		$(By.id(cancelbutton)).waitUntil(visible, 30000).click();
		Thread.sleep(5000);
		     System.out.println("awe");
		 
}
//	@Test
//	@Order(6)
	public void Single_Document_pricing_search_myapproval_screen() throws InterruptedException, AWTException, IOException {
//		String successtemplateActual = $(By.id(Chooseyouraccounttype)).waitUntil(visible, 30000).getText();
//		String successtemplateActualExpected = Chooseyouraccounttypeval;
//		Assertions.assertTrue(successtemplateActualExpected.contains((AccounttypeActual)));
		Thread.sleep(3000);
		 System.out.println("task2");
		 $(By.xpath(pricingmain)).waitUntil(visible, 30000).click();
		 Thread.sleep(4000);
		 $(By.xpath(myapprovals)).waitUntil(visible, 30000).click();
		 //PRIREM__acc_pricing__el_inp_1
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).click();
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("123456789");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//span[@id='PRIREM__pricing__el_txt_6_txtcnt']
//		 String imagetextActual = $(By.xpath(norecordsfoundtext)).waitUntil(visible, 30000).getText();
//			String imagetextActualExpected = "No Records Found!";
//			Assertions.assertTrue(imagetextActualExpected.equals((imagetextActual)));
	     Thread.sleep(4000);
//	     $(By.id("PRIREM__pricing__serarchbox")).waitUntil(visible, 30000).clear();
//	     $(By.id("PRIREM__pricing__serarchbox")).waitUntil(visible, 30000).sendKeys("12345678");
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys(Keys.BACK_SPACE);
	     Thread.sleep(6000);
//	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
//		    String Accountnumber1Actual = $(By.id(Accountnumbervalue1)).waitUntil(visible, 30000).getText();
//			String Accountnumber1ActualExpected = "12345678";
//			Assertions.assertTrue(Accountnumber1ActualExpected.equals((Accountnumber1Actual)));
		//$(By.xpath(myapprovals)).waitUntil(visible, 30000).click();
//	    String AccountnumberActual = $(By.id(Accountnumbervalue)).waitUntil(visible, 30000).getText();
//		String AccountnumberActualExpected = "12345678";
//		Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		$(By.id(myrequestsforwardicon)).waitUntil(visible, 30000).click();
		System.out.println("qqw");
	}
//	@Test
//	@Order(7)
	public void Single_Document_myrequest_search_myapproval_screen() throws InterruptedException, AWTException, IOException {

		//String successtemplateActual = $(By.id(Chooseyouraccounttype)).waitUntil(visible, 30000).getText();
//		String successtemplateActualExpected = Chooseyouraccounttypeval;
//		Assertions.assertTrue(successtemplateActualExpected.contains((AccounttypeActual)));
		Thread.sleep(3000);
		 //PRIREM__acc_pricing__el_inp_1
		 $(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		 Thread.sleep(4000);
	   //  Assertions.assertTrue($(By.xpath("//img[@id='PRIREM__pricing__el_img_1']")).waitUntil(visible, 30000).is(visible));imp
	     Thread.sleep(4000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
//	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		$(By.id(All)).waitUntil(visible, 30000).click();
		//PRIREM__popup__i__main__cat_1_txtcnt
		$(By.id(swiftnet)).waitUntil(visible, 30000).click();
		Thread.sleep(2000);
		//$(By.xpath(Downloadtemplatemy)).waitUntil(visible, 30000).click();
		System.out.println("121");
		Thread.sleep(3000);
		
		
	}
//	@Test
//	@Order(4)
	public void Multi_Document_pricing_approval_search_screen() throws InterruptedException, AWTException, IOException {//imp
		Thread.sleep(5000);
		 $(By.xpath(pricingmain)).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 $(By.xpath(myrequestsmenu)).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 $(By.id(murequestsmain)).waitUntil(visible, 30000).click();
		 //PRIREM__acc_pricing__el_inp_1
	      $(By.id(searchboxnext)).waitUntil(visible, 30000).click();//im
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("123456789");//im
	  
          Thread.sleep(2000);
	     Assertions.assertTrue($(By.xpath("//img[@id='PRIREM__pricing__el_img_1']")).waitUntil(visible, 30000).is(visible));
         Thread.sleep(4000);
          $(By.id(searchboxnext)).waitUntil(visible, 30000).clear();
          Thread.sleep(2000);
          $(By.id(murequestsmain)).waitUntil(visible, 30000).click();
	     Thread.sleep(4000);
	   ////  $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys(Keys.BACK_SPACE);
//	     $(By.id("PRIREM__pricing__serarchbox")).waitUntil(visible, 30000).sendKeys(Keys.P);
//	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
	     Thread.sleep(4000);
	   //  $(By.id("PRIREM__pricing__serarchbox")).waitUntil(visible, 30000).sendKeys("5678");
	     Thread.sleep(6000);
	      $(By.id(multiaccountbutton)).waitUntil(visible, 30000).click();
	      Thread.sleep(6000);
		    String Accountnumber1Actual = $(By.xpath("//span[@id='PRIREM__pricing__o__common__Accounts_0_txtcnt']")).waitUntil(visible, 30000).getText();
			String Accountnumber1ActualExpected = "12345678";
			Assertions.assertTrue(Accountnumber1Actual.contains((Accountnumber1ActualExpected)));
			$(By.id(myrequestsforwardicon1)).waitUntil(visible, 30000).click();
		    // $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		     System.out.println("awe");
		 
	}
	public void Multi_Document_pricing_approval_screen() throws InterruptedException, AWTException, IOException {//imp
		Thread.sleep(5000);
		 $(By.xpath(pricingmain)).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 $(By.id(multiaccountbutton)).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).click();
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("123456789");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//img[@id='PRIREM__pricing__el_img_1']
		  Thread.sleep(5000);
			String imagetextActual = $(By.xpath(norecordsfoundtext)).waitUntil(visible, 35000).getText();
			Thread.sleep(2000);
			String imagetextActualExpected = "No Records Found!";
			Assertions.assertTrue(imagetextActualExpected.equals((imagetextActual)));
	//     Assertions.assertTrue($(By.xpath("//img[@id='PRIREM__pricing__el_img_1']")).waitUntil(visible, 30000).is(visible));
	     Thread.sleep(4000);
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).clear();
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("12345678");
//		 $(By.id("PRIREM__pricing__el_icn_9_0")).waitUntil(visible, 30000).click();
	     Thread.sleep(2000);
	     $(By.id(multiaccountbutton)).waitUntil(visible, 30000).click();
	   //span[@id='PRIREM__pricing__o__common__Accounts_0_txtcnt']
		    String Accountnumber1Actual = $(By.xpath("//span[@id='PRIREM__pricing__o__common__Accounts_0_txtcnt']")).waitUntil(visible, 30000).getText();
		    Thread.sleep(2000);
			String Accountnumber1ActualExpected = "12345678";
			Assertions.assertTrue(Accountnumber1Actual.contains((Accountnumber1ActualExpected)));
			Thread.sleep(2000);
			$(By.id(myrequestsforwardicon1)).waitUntil(visible, 30000).click();
		    // $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		     System.out.println("awe");
		 
	}
	public void Multi_Document_template_approval_screen() throws InterruptedException, AWTException, IOException { //imp
		Thread.sleep(5000);
		$(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//img[@id='PRIREM__pricing__el_img_1']
		  Thread.sleep(2000);                 //img[@id='PRIREM__acc_pricing__el_img_1']
	     Assertions.assertTrue($(By.xpath("//img[@id='PRIREM__acc_pricing__el_img_1']")).waitUntil(visible, 30000).is(visible));
	     Thread.sleep(2000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
		$(By.id(All)).waitUntil(visible, 30000).click();
		//PRIREM__popup__i__main__cat_1_txtcnt
		$(By.id(swiftnet)).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		$(By.id(Approvebutton)).waitUntil(visible, 30000).click();
//		$(By.id(cancelbutton)).waitUntil(visible, 30000).click();
		Thread.sleep(5000);
		     System.out.println("awe");
		     }
	public void Multi_Document_pricing_myapproval_screen() throws InterruptedException, AWTException, IOException {                    //imp
//		String successtemplateActual = $(By.id(Chooseyouraccounttype)).waitUntil(visible, 30000).getText();
//		String successtemplateActualExpected = Chooseyouraccounttypeval;
//		Assertions.assertTrue(successtemplateActualExpected.contains((AccounttypeActual)));
		//PRIREM__pricing__el_rdo_1_option_myReq_span_
		Thread.sleep(5000);
		 System.out.println("task2");
		 $(By.xpath(myapprovals)).waitUntil(visible, 30000).click();
		//$(By.xpath(myapprovals)).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 $(By.id(multiaccountbutton)).waitUntil(visible, 30000).click();
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).click();
		 $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("123456788");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//img[@id='PRIREM__pricing__el_img_1']
		  Thread.sleep(2000);
	     Assertions.assertTrue($(By.xpath(norecordsfoundimage)).waitUntil(visible, 30000).is(visible));
	     Thread.sleep(2000);
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).clear();
	     $(By.id(searchboxnext)).waitUntil(visible, 30000).sendKeys("12345678");
	     $(By.id(multiaccountbutton)).waitUntil(visible, 30000).click();
		   //span[@id='PRIREM__pricing__o__common__Accounts_0_txtcnt']
			    String Accountnumber1Actual = $(By.xpath("//span[@id='PRIREM__pricing__o__common__Accounts_0_txtcnt']")).waitUntil(visible, 30000).getText();
			    Thread.sleep(2000);
			String Accountnumber1ActualExpected = "12345678";
			Assertions.assertTrue(Accountnumber1Actual.contains((Accountnumber1ActualExpected)));
		$(By.id(myrequestsforwardicon)).waitUntil(visible, 30000).click();
		System.out.println("qqw");
	}
	public void Multi_Document_myrequest_approval_screen() throws InterruptedException, AWTException, IOException {            //imp
		Thread.sleep(3000);
		 $(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		//img[@id='PRIREM__pricing__el_img_1'] //img[@id='PRIREM__pricing__el_img_1']
		  Thread.sleep(5000);               //img[@id='PRIREM__pricing__el_img_1']
//	     Assertions.assertTrue($(By.xpath("//span[@id='PRIREM__acc_pricing__el_txt_14_txtcnt']")).waitUntil(visible, 30000).is(visible));
			String imagetextActual = $(By.xpath(norecordsfoundtext1)).waitUntil(visible, 30000).getText();
			 Thread.sleep(2000);
			String imagetextActualExpected = "No Records Found!";
			Assertions.assertTrue(imagetextActualExpected.equals((imagetextActual)));
	     Thread.sleep(2000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
		$(By.id(All)).waitUntil(visible, 30000).click();
		//PRIREM__popup__i__main__cat_1_txtcnt
		$(By.id(swiftnet)).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		Thread.sleep(3000);
		
		
	}
	
	}
