package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;
import junit.framework.Assert;
@TestMethodOrder(OrderAnnotation.class)
public class I_search_pricing_multi extends BaseTest{
	//LoginTestsingle Call=new LoginTestsingle();
	C_Login_Test_multi Call1=new C_Login_Test_multi();
	x_logout multicall=new x_logout();
	D_adminflow_approve_test_multi multiflow=new D_adminflow_approve_test_multi();
	@BeforeAll
	public static void Begin() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		//open("http://10.32.2.51:8483/SocieteGenerale/");
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}
	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")
	
	
	public void Multi_Document_serach_start() throws IOException, InterruptedException, AWTException {
		Call1.Multi_Document_start1();     
		Thread.sleep(5000);
		 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
		// Selenide thread = null;
		Thread.sleep(4000);
		 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
		 //$(By.id(singleaccountinputbox)).waitUntil(visible, 30000).sendKeys(singleaccountinputboxval);
		 Thread.sleep(2000);
		 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
		 Thread.sleep(2000);
		 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
		 Robot robot = new Robot();
		 String path = "/home/i-exceed.com/udhayakumar.s/Documents/soc automation(feb 3)/upload template test case(socgen)automation(feb 3)/Multi/Positive TC/TC_5  new 2 product code.xlsx";
		    StringSelection stringSelection = new StringSelection(path);
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents(stringSelection, stringSelection);
	Thread.sleep(5000);
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    Thread.sleep(500);
		    robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
			 Thread.sleep(6000);
			 $(By.xpath("//span[@id='PRIREM__ChargeUpload__el_hpl_3_txtcnt']")).waitUntil(visible, 30000).click();
			 Thread.sleep(2000);
			
		 //PRIREM__acc_pricing__el_inp_1
		 $(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
		 Thread.sleep(2000);
	     Assertions.assertTrue($(By.id(searchnotfoundimage)).waitUntil(visible, 30000).is(visible));
		 Thread.sleep(2000);
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
			String AccountnumberActualExpected = Accountnumbervaluesearch1;
			Assertions.assertTrue(AccountnumberActual.contains((AccountnumberActualExpected)));
		 $(By.id(All)).waitUntil(visible, 30000).click();
			//PRIREM__popup__i__main__cat_1_txtcnt
			//$(By.id(swiftnet)).waitUntil(visible, 30000).click();
			$(By.id(downloadtemprequest1)).waitUntil(visible, 30000).click();
			Thread.sleep(4000);
		 $(By.id(submitbutton1)).waitUntil(visible, 30000).click();
		 //$(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		 
			//Runtime.getRuntime().exec("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx");	
		     System.out.println("awe");
	      Call1.Multi_Document_success_template1_screen();
          multicall.Multi_Document_pricing_approval_search_screen();
//		 Call1.myrequest1();
		     //Call3.
		   //  multicall.Multi_Document_myrequest_approval_screen();
		     System.out.println("jjjj");
		     multicall.Logout_popup();
		     System.out.println("kk");
		     
		     
	}
	@Test
	@Order(2)
	public void Serach_End_Single() throws IOException, InterruptedException, AWTException {
 		multiflow.Multi_Document_start();
     	//multicall.pricingapprovalsearchmulti();
     	multicall.Multi_Document_pricing_approval_screen();
        System.out.println("1");
     	multicall.Multi_Document_template_approval_screen();
     	 System.out.println("2");
     	multiflow.Multi_Document_success_template_screen();
     	multicall.Multi_Document_pricing_myapproval_screen();
     	 System.out.println("3");
     	multicall.Multi_Document_myrequest_approval_screen();
     	
     	
     	
     	 System.out.println("4");
     	
//		Call3.pricingapprovalsearch();
//		System.out.println("1");
//		Call3.templateapprovalscreensearch();
//		System.out.println("2");
//		Call2.successtemplate();
//	    Call3.pricingsearchmyapproval();
//	    System.out.println("3");
//	    Call3.myrequestsearchmyapproval();
	}
	}
