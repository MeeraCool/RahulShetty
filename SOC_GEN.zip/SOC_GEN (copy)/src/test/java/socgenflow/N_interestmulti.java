package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;

@TestMethodOrder(OrderAnnotation.class)
public class N_interestmulti extends BaseTest {

	@BeforeAll
	public static void Begin() throws InterruptedException {
		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}

	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")

	public void Multi_Document_start1() throws IOException, InterruptedException {
		Thread.sleep(5000);
		$(By.id(soclogininputbox)).waitUntil(visible, 30000).sendKeys(socloginval);
		$(By.id(socpasswordinputbox)).waitUntil(visible, 30000).sendKeys(socpasswordval);
		$(By.id(socloginbutton)).shouldBe(visible).click();
		Thread.sleep(5000);
		Selenide.screenshot("HomeScreen");
		System.out.println("123");
	}

	@Test
	@Order(2)
	public void Multi_Document_template_upload_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		$(By.xpath("//a[contains(text(),'Interest Template Upload')]")).waitUntil(visible, 30000).click();
		Thread.sleep(4000);
		$(By.xpath("//label[@id='PRIREM__InterestUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000)
				.click();
		Thread.sleep(2000);
		$(By.xpath("//button[@id='PRIREM__InterestUpload__uploadbt']")).click();
		Thread.sleep(2000);
		Robot robot = new Robot();
		String path = "/home/i-exceed.com/udhayakumar.s/Desktop/int/multiAccout_Interest - Copy (2).xlsx";
		StringSelection stringSelection = new StringSelection(path);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
		Thread.sleep(5000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		Thread.sleep(500);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(6000);
		$(By.xpath("//span[@id='PRIREM__InterestUpload__el_hpl_3_txtcnt']")).waitUntil(visible, 30000).click();
		Thread.sleep(3000);
		$(By.xpath("//label[@id='PRIREM__acc_pricing__el_rdo_1_option_CRE_span_']")).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest1)).waitUntil(visible, 30000).click();
		Thread.sleep(4000);
		$(By.id(submitbutton1)).waitUntil(visible, 30000).click();
		Thread.sleep(6000);
		System.out.println("awe");

	}

	@Test
	@Order(3)
	public void Multi_Document_success_template1_screen() throws InterruptedException, AWTException, IOException {// imp
		Selenide.screenshot("Choose your account type screen");
		Thread.sleep(5000);
		$(By.id(success)).waitUntil(visible, 30000).click();
		System.out.println("task1");
	}

	@Test
	@Order(4)
	public void Multi_Document_pricing1_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		System.out.println("task2");
		Thread.sleep(15000);
		$(By.xpath("//label[@id='PRIREM__pricing__el_rdo_1_option_myReq_span_']")).waitUntil(visible, 50000).click();
		$(By.id(myrequestsforwardicon)).waitUntil(visible, 30000).click();
		System.out.println("qqw");
	}

	@Test
	@Order(5)
	public void Multi_Document_myrequest1_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(4000);
		$(By.xpath("//label[@id='PRIREM__acc_pricing__el_rdo_1_option_CRE_span_']")).waitUntil(visible, 30000).click();
		Thread.sleep(3000);
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("multi");
		Thread.sleep(3000);

	}

}
