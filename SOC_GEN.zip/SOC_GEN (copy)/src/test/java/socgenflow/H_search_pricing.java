package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;
import junit.framework.Assert;
@TestMethodOrder(OrderAnnotation.class)
public class H_search_pricing extends BaseTest{
	A_Login_Test_single Call=new A_Login_Test_single();
	C_Login_Test_multi Call1=new C_Login_Test_multi();
	B_adminflow_approve_test Call2=new B_adminflow_approve_test();
	x_logout Call3=new x_logout();
	
	@BeforeAll
	public static void begin() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		//open("http://10.32.2.51:8483/SocieteGenerale/");
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}
	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")
	
	
	public void serach_start_single() throws IOException, InterruptedException, AWTException {
		Call.Single_Document_start();        
		
	//}@Test
	//@Order(2)
	//public void templateuploadsinglesearch() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
		 $(By.xpath("//input[@id='PRIREM__ChargeUpload__accNumLov']")).waitUntil(visible, 30000).sendKeys(singleaccountinputboxval);
		 Thread.sleep(2000);
		 $(By.id("PRIREM__ChargeUpload__uploadbt")).click();
		 Thread.sleep(2000);
		 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
		 Robot robot = new Robot();
		 String path = "/home/i-exceed.com/udhayakumar.s/Documents/soc automation(feb 3)/upload template test case(socgen)automation(feb 3)/single/Positive TC/TC_1 valid 1 acc.xlsx";
		    StringSelection stringSelection = new StringSelection(path);
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents(stringSelection, stringSelection);
	Thread.sleep(5000);
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    Thread.sleep(500);
		      robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
		 Thread.sleep(7000);
		 $(By.xpath("//span[@id='PRIREM__ChargeUpload__el_hpl_3_txtcnt']")).waitUntil(visible, 30000).click();
		 Thread.sleep(2000);
		 //PRIREM__acc_pricing__el_inp_1
		 Thread.sleep(2000);
		 $(By.id(searchbox)).waitUntil(visible, 30000).click();
		 $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("123456788888");
	    // String image;
		//Assert.assertTrue(image, isvisible);
	     Assertions.assertTrue($(By.id(searchnotfoundimage)).is(visible));
	     $(By.id(searchbox)).waitUntil(visible, 30000).clear();
	     $(By.id(searchbox)).waitUntil(visible, 30000).sendKeys("12345678");
	     String AccountnumberActual = $(By.id(Accountnumbervaluesearch)).waitUntil(visible, 30000).getText();
			String AccountnumberActualExpected = "12345678";
			Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		 $(By.id(All)).waitUntil(visible, 30000).click();
			//PRIREM__popup__i__main__cat_1_txtcnt
			$(By.id(swiftnet)).waitUntil(visible, 30000).click();
			$(By.id(downloadtemprequest1)).waitUntil(visible, 30000).click();
			Thread.sleep(4000);
		 $(By.id(submitbutton1)).waitUntil(visible, 30000).click();
		 //$(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		 
			//Runtime.getRuntime().exec("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx");	
		     System.out.println("awe");
		 Call.Single_Document_success_template_screen();
		 Call.Single_Document_pricing_screen();
		 Call3.Single_Document_myrequest_search_screen();
		 Call3.Logout_popup();
		System.out.println("6324763432");
	}
	@Test
	@Order(2)
	public void serachendsingle() throws IOException, InterruptedException, AWTException {
		Call2.Single_Document_start();
		Call3.Single_Document_pricing_approval_search_screen();
		System.out.println("1");
		Call3.Single_Document_template_approval_screen_search_screen();
		System.out.println("2");
		Call2.Single_Document_success_template_screen();
	    Call3.Single_Document_pricing_search_myapproval_screen();
	    System.out.println("3");
	    Call3.Single_Document_myrequest_search_myapproval_screen();
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public void serachstartmulti() throws IOException, InterruptedException, AWTException {
//		Call.start();        
//		
//	//}@Test
//	//@Order(2)
//	//public void templateuploadsinglesearch() throws InterruptedException, AWTException, IOException {
//		Thread.sleep(5000);
//		 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
//		// Selenide thread = null;
//		Thread.sleep(4000);
//		 $(By.id(multiaccount)).waitUntil(visible, 40000).click();
//		 //$(By.id(singleaccountinputbox)).waitUntil(visible, 30000).sendKeys(singleaccountinputboxval);
//		 Thread.sleep(2000);
//		 $(By.id(uploadbutton)).click();
//		 Thread.sleep(2000);
//		 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
//		 Robot robot = new Robot();
//		 String path = "/home/i-exceed.com/udhayakumar.s/Documents/soc automation(feb 3)/upload template test case(socgen)automation(feb 3)/Multi/Positive TC/TC_4  valid 2 product code.xlsx";
//		    StringSelection stringSelection = new StringSelection(path);
//		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
//		    clipboard.setContents(stringSelection, stringSelection);
//	Thread.sleep(5000);
//		    robot.keyPress(KeyEvent.VK_CONTROL);
//		    robot.keyPress(KeyEvent.VK_V);
//		    robot.keyRelease(KeyEvent.VK_V);
//		    robot.keyRelease(KeyEvent.VK_CONTROL);
//		    Thread.sleep(500);
//		    robot.keyPress(KeyEvent.VK_ENTER);
//			 robot.keyRelease(KeyEvent.VK_ENTER);
//			 Thread.sleep(6000);
//			 $(By.id(Accountpricingreconciliation)).waitUntil(visible, 30000).click();
//			 Thread.sleep(2000);
//			
//		 //PRIREM__acc_pricing__el_inp_1
//		 $(By.id("PRIREM__acc_pricing__el_inp_1")).waitUntil(visible, 30000).click();
//		 $(By.id("PRIREM__acc_pricing__el_inp_1")).waitUntil(visible, 30000).sendKeys("123456788888");
//	    // String image;
//		//Assert.assertTrue(image, isvisible);
//		 Thread.sleep(2000);
//	     Assertions.assertTrue($(By.id("PRIREM__acc_pricing__el_img_1")).is(visible));
//	     $(By.id("PRIREM__acc_pricing__el_inp_1")).waitUntil(visible, 30000).clear();
//	     $(By.id("PRIREM__acc_pricing__el_inp_1")).waitUntil(visible, 30000).sendKeys("12345678");
//	     Thread.sleep(2000);
//	     String AccountnumberActual = $(By.id(Accountnumbervalue)).waitUntil(visible, 30000).getText();
//			String AccountnumberActualExpected = "12345678";
//			Assertions.assertTrue(AccountnumberActual.contains((AccountnumberActualExpected)));
//		 $(By.id(All)).waitUntil(visible, 30000).click();
//			//PRIREM__popup__i__main__cat_1_txtcnt
//			$(By.id(swiftnet)).waitUntil(visible, 30000).click();
//			$(By.id("PRIREM__acc_pricing__el_hpl_1_txtcnt")).waitUntil(visible, 30000).click();
//			Thread.sleep(4000);
//		 $(By.id(submitbutton1)).waitUntil(visible, 30000).click();
//		 //$(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
//		 
//			//Runtime.getRuntime().exec("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx");	
//		     System.out.println("awe");
//		 Call1.successtemplate1();
//		 Call1.pricing1();
//		 Call1.myrequest1();
//		 System.out.println("232143");
//		 
//	}
//	public void adminflowapprovetestsearch() {
//		
//		//Call2.
//	}}
