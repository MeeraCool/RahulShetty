package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;

@TestMethodOrder(OrderAnnotation.class)
public class L11 extends BaseTest {

	// private static final String Accountnumbervalue1 = null;
	@BeforeAll
	public static void Begin() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}

	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")

	public void Single_Document_start() throws IOException, InterruptedException {
		Thread.sleep(5000);
		$(By.id(soclogininputbox)).waitUntil(visible, 30000).sendKeys(socloginval1);
		$(By.id(socpasswordinputbox)).waitUntil(visible, 30000).sendKeys(socpasswordval1);
		$(By.id(socloginbutton)).shouldBe(visible).click();
		Thread.sleep(10000);
		Selenide.screenshot("HomeScreen");
		System.out.println("123");
	}

	@Test
	@Order(2)
	public void Single_Document_pricing_approval_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		$(By.xpath(pricingmain)).waitUntil(visible, 30000).click();
		String Accountnumber1Actual = $(By.id(Accountnumbervalue1)).waitUntil(visible, 30000).getText();
		String Accountnumber1ActualExpected = "12345678";
		Assertions.assertTrue(Accountnumber1ActualExpected.equals((Accountnumber1Actual)));
		$(By.id(myrequestsforwardicon1)).waitUntil(visible, 30000).click();
		System.out.println("awe");

	}

	@Test
	@Order(3)
	public void Single_Document_template_approval_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		$(By.xpath("//label[@id='PRIREM__acc_pricing__el_rdo_1_option_CRE_span_']")).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		$(By.id(Approvebutton)).waitUntil(visible, 30000).click();
		Thread.sleep(5000);
		System.out.println("awe");

	}

	@Test
	@Order(4)
	public void Single_Document_success_template_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(2000);
		$(By.id(success)).waitUntil(visible, 30000).click();
		Thread.sleep(5000);
	}

	@Test
	@Order(5)
	public void Single_Document_pricing_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		System.out.println("task2");
		Thread.sleep(5000);
		$(By.xpath(myapprovals)).waitUntil(visible, 50000).click();
		String AccountnumberActual = $(By.id(Accountnumbervalue)).waitUntil(visible, 30000).getText();
		String AccountnumberActualExpected = "12345678";
		Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		$(By.id(myrequestsforwardicon)).waitUntil(visible, 30000).click();
		System.out.println("qqw");
	}

	@Test
	@Order(6)
	public void Single_Document_myrequest_screen() throws InterruptedException, AWTException, IOException {
		Thread.sleep(4000);
		$(By.xpath("//label[@id='PRIREM__acc_pricing__el_rdo_1_option_CRE_span_']")).waitUntil(visible, 30000).click();
		$(By.id(downloadtemprequest)).waitUntil(visible, 30000).click();
		System.out.println("121");
		Thread.sleep(3000);

	}
}
