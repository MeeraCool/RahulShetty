package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;

@TestMethodOrder(OrderAnnotation.class)
public class G_RMDashboard extends BaseTest {

	@BeforeAll
	public static void begining() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		//open("http://10.32.2.51:8483/SocieteGenerale/");
		//open("http://10.32.2.101:8586/SocieteGenerale/");
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}
	@Test
	@Order(1)
	@DisplayName("positiveflow")
//	@Tag("Functionality_Positive")
	@Tag("socgen ")

	public void RMDashboard_start() throws IOException, InterruptedException {

		Thread.sleep(5000);

		$(By.id(soclogininputbox)).waitUntil(visible, 30000).sendKeys("admin");
		$(By.id(socpasswordinputbox)).waitUntil(visible, 30000).sendKeys("admin");
		$(By.id(socloginbutton)).shouldBe(visible).click();

		Thread.sleep(5000);
		Selenide.screenshot("HomeScreen");
		System.out.println("123");
	}
	@Test
	@Order(2)
	
	public void RMDashboard_Activityflow() throws IOException, InterruptedException {
		Thread.sleep(2000);
		$(By.id("SOCMIC__Dashboard__el_hpl_2_0")).shouldBe(visible).click();
		//String AccountnumberActual = $(By.xpath(DDAaccountnumber)).waitUntil(visible, 30000).getText();
		String AccountnumberActualExpected = "1234";
		//Assertions.assertTrue(AccountnumberActualExpected.equals((AccountnumberActual)));
		$(By.id(viewicon)).shouldBe(visible).click();
		$(By.id(Actitvitystatementbutton)).shouldBe(visible).click();
		Thread.sleep(3000);
	    $(By.id(Asfromdateinput)).shouldBe(visible).sendKeys("01-Mar-2019");
		$(By.xpath(Asoneicon)).shouldBe(visible).click();
		Thread.sleep(5000);
		//select[@class='ui-datepicker-year']
		//$(By.xpath("//select[@class='ui-datepicker-year']")).shouldBe(visible).click();
		  $(By.id(Astodateinput)).shouldBe(visible).sendKeys("01-Feb-2020");
			$(By.xpath(Astwoicon)).shouldBe(visible).click();
			Thread.sleep(5000);
		  $(By.id(Searchbutton)).shouldBe(visible).click();
		  Thread.sleep(5000);
		  $(By.id("SOCMIC__ActivityStmt__sc_col_29_li")).shouldBe(visible).click();
		  Thread.sleep(5000);
		   $(By.id(Asforwardicon)).shouldBe(visible).click();
		  Thread.sleep(2000);
//		  String titlepopupActual = $(By.xpath("//span[@id='SOCMIC__DDAdetails__o__apzvwDdaDetails__accountNo_0_txtcnt']")).waitUntil(visible, 30000).getText();
//			String titlepopupActualExpected = "More Details";
//			Assertions.assertTrue(titlepopupActualExpected.equals((titlepopupActual)));imp
			//div[@id='pt-main']//ul[@class='modal-header']//li[2]
			 $(By.xpath(intoOption)).shouldBe(visible).click();
			 Thread.sleep(2000);
			   $(By.id(Asbackicon)).shouldBe(visible).click();
			   Thread.sleep(2000);
	}
	@Test
	@Order(3)
	public void RMDashboard_ivoiceflow() throws IOException, InterruptedException {
		
		 $(By.id(Invoicebutton)).shouldBe(visible).click();
		 String optionstwoActual = $(By.xpath(invoicelabel)).waitUntil(visible, 30000).getText();
			String optionstwoActualExpected = "Invoice";
			Assertions.assertTrue(optionstwoActualExpected.equals((optionstwoActual)));
			Thread.sleep(2000);
		 $(By.id(billingperiod )).shouldBe(visible).click();
		 $(By.xpath(billingperoidmonth)).shouldBe(visible).click();
		 $(By.id(searchbuttoninvoice)).shouldBe(visible).click();
		 $(By.id(invoiceback)).shouldBe(visible).click();
		 System.out.println("123");
		
		
	}
	@Test
	@Order(4)
	public void RMDashboard_chargepricing_flow() throws IOException, InterruptedException {
		Thread.sleep(2000);
		 $(By.id(chargepricingbutton)).shouldBe(visible).click();
		 Thread.sleep(2000);
		 String optionsthreeActual = $(By.xpath(chargepricinglabel)).waitUntil(visible, 30000).getText();
			String optionsthreeActualExpected = "Charge Pricing";
			Assertions.assertTrue(optionsthreeActualExpected.equals((optionsthreeActual)));
		 $(By.id(chargepricingback)).shouldBe(visible).click();
		 System.out.println("life");
		
		
	}
	@Test
	@Order(5)
	public void RMDashboard_interestpricing_flow() throws IOException, InterruptedException {
		
		 $(By.xpath(interestpricingbutton)).shouldBe(visible).click();
		 Thread.sleep(2000);
		 String optionsfourActual = $(By.xpath(interestpricinglabel)).waitUntil(visible, 30000).scrollTo().getText();
			String optionsfourActualExpected = "Interest Pricing";
			Assertions.assertTrue(optionsfourActualExpected.equals((optionsfourActual)));
		 $(By.id(interestpricingback)).shouldBe(visible).click();
		 System.out.println("task4");
		
		
	}
	@Test
	@Order(6)
	public void RMDashboard_balancetrend_flow() throws IOException, InterruptedException {
		
		 $(By.xpath(balancetrendbutton)).shouldBe(visible).click();
		 Thread.sleep(2000);//h5[@id='SOCGEN__LandingPage__subHeaderTxt']
//		 String optionsfiveActual = $(By.id("SOCGEN__LandingPage__subHeaderTxt")).waitUntil(visible, 30000).scrollTo().getText();
//			String optionsfiveActualExpected = "Balance Trend";
//			Assertions.assertTrue(optionsfiveActualExpected.equals((optionsfiveActual)));
//		 $(By.id("SOCMIC__BalTrend__bt_fromdate")).shouldBe(visible).clear();
//		 $(By.id("SOCMIC__BalTrend__bt_fromdate")).shouldBe(visible).sendKeys("19-Aug-2019");
//		 $(By.id("SOCMIC__BalTrend__bt_todate")).shouldBe(visible).clear();
//		 $(By.id("SOCMIC__BalTrend__bt_todate")).shouldBe(visible).sendKeys("19-Feb-2020");
		 $(By.id(balancetrendlabel)).shouldBe(visible).click();
		 Thread.sleep(4000);
		// SOCGEN__LandingPage__el_btn_1
		 $(By.id(balancetrendback)).shouldBe(visible).click();
		 System.out.println("task5");
		
		
	}
	@Test
	@Order(7)
	public void RMDashboard_bilingtrend_flow() throws IOException, InterruptedException {
		
		 $(By.xpath(billingtrendbutton)).shouldBe(visible).click();
		 Thread.sleep(2000);
//		 String optionssixActual = $(By.id("SOCGEN__LandingPage__subHeaderTxt")).waitUntil(visible, 30000).scrollTo().getText();
//			String optionssixActualExpected = "Billing Trend";
//			Assertions.assertTrue(optionssixActualExpected.equals((optionssixActual)));
		// $(By.id("SOCMIC__BillTrend__bt_fromdate")).shouldBe(visible).click();
		 // $(By.id("SOCMIC__BillTrend__bt_fromdate")).shouldBe(visible).clear();
		// $(By.id("SOCMIC__BillTrend__bt_fromdate")).shouldBe(visible).sendKeys("01-Feb-2019");
		 $(By.id(billingtrendfromdate)).shouldBe(visible).click();
		 Thread.sleep(2000);
		 $(By.id(billingtrendfromdate)).shouldBe(visible).clear();
		 //$(By.id("SOCMIC__BillTrend__bt_fromdate")).shouldBe(visible).sendKeys("01-Feb-2019");
		 Thread.sleep(2000);
		 $(By.id(billingtrendfromdate)).shouldBe(visible).sendKeys("01-Mar-2019");
			$(By.xpath(btoneicon)).shouldBe(visible).click();
		 Thread.sleep(3000);
		 $(By.xpath(bttodate)).shouldBe(visible).click();
		 Thread.sleep(3000);
		 $(By.xpath(bttodate)).shouldBe(visible).clear();
		 Thread.sleep(3000);
		 $(By.xpath(bttodate)).shouldBe(visible).sendKeys("01-Feb-2020");
		 $(By.xpath(bttwoicon)).shouldBe(visible).click();
		 System.out.println("task6");
		 //$(By.id("SOCMIC__BalTrend__el_btn_4")).shouldBe(visible).click();
		 Thread.sleep(2000);
		// SOCGEN__LandingPage__el_btn_1
		 $(By.xpath(billingtrendback)).shouldBe(visible).click();
		 System.out.println("task6");
		
		
	}
	

}