package socgenflow;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.openqa.selenium.By;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;

import generic.BaseTest;
@TestMethodOrder(OrderAnnotation.class)
public class F_invalid_multidoc_template_upload extends BaseTest{
	
	@BeforeAll
	public static void Begin() throws InterruptedException {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		//open("http://10.32.2.51:8483/SocieteGenerale/");
		open("http://10.32.2.51:8483/SocieteGenerale/");
		Thread.sleep(3000);
	}
	@Test
	@Order(1)
	@DisplayName("positiveflow")
	@Tag("Functionality_Positive")

	
	public void Multi_Document_start() throws IOException, InterruptedException {

		Thread.sleep(5000);
	 
	    	$(By.id(soclogininputbox)).waitUntil(visible,30000).sendKeys(socloginval);
		
		    $(By.id(socpasswordinputbox)).waitUntil(visible, 30000).sendKeys(socpasswordval);
  		    $(By.id(socloginbutton)).shouldBe(visible).click();

		Thread.sleep(5000);
		Selenide.screenshot("HomeScreen");
		System.out.println("123");
	}
			
	@Test
	@Order(2)
	public void Template_upload_screen_different_effectivedate_for_Multi_Document() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);
		 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
		 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
		 Thread.sleep(2000);
		 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
		 Thread.sleep(2000);
		 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
		 Robot robot = new Robot();
		 String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_9    2 different eff date multi.xlsx";
		    StringSelection stringSelection = new StringSelection(path);
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents(stringSelection, stringSelection);
            Thread.sleep(500);
		    robot.keyPress(KeyEvent.VK_CONTROL);
		    robot.keyPress(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_V);
		    robot.keyRelease(KeyEvent.VK_CONTROL);
		    Thread.sleep(500);
		    robot.keyPress(KeyEvent.VK_ENTER);
			 robot.keyRelease(KeyEvent.VK_ENTER);
		// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
		 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
			String invaliddateformatActualExpected =invaliddateformatdiffereffectiveexpectedtext;
			Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
		 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
		 Thread.sleep(6000);
		
		     System.out.println("invalid1");
		 
	}
@Test
@Order(3)
public void Template_upload_screen_invalid_effectivedate_for_Multi_Document() throws InterruptedException, AWTException, IOException {
	Thread.sleep(5000);
	 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
	 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
	 Thread.sleep(2000);
	 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
	 Thread.sleep(2000);
	 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
	 Robot robot = new Robot();
	   String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_10    invalid eff date multi.xlsx";
	    StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
        Thread.sleep(5000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(500);
	    robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_ENTER);
	// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
	 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
		String invaliddateformatActualExpected =invaliddateformattextvalue;
		Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
	 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
	 Thread.sleep(6000);
	
	     System.out.println("invalid2");
	 
}
@Test
@Order(4)
public void Template_upload_invalid_effectivedate_for_MultiDocument() throws InterruptedException, AWTException, IOException {
	Thread.sleep(5000);
	 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
	 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
	 Thread.sleep(2000);
	 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
	 Thread.sleep(2000);
	 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
	 Robot robot = new Robot();
	   String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_10    invalid eff date multi-date.xlsx";
	    StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
        Thread.sleep(5000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(500);
	    robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_ENTER);
	// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
	 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
		String invaliddateformatActualExpected =invaliddateformattextvalue;
		Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
	 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
	 Thread.sleep(6000);
	
	     System.out.println("invalid3");
	 
}
@Test
@Order(5)
public void Template_upload_screen_invalid_effectivedate_for_MultiDocument() throws InterruptedException, AWTException, IOException {
	Thread.sleep(5000);
	 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
	 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
	 Thread.sleep(2000);
	 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
	 Thread.sleep(2000);
	 //$(By.xpath("/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_10    invalid eff date multi-month.xlsx"));
	 Robot robot = new Robot();
	   String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_10    invalid eff date multi.xlsx";
	    StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
        Thread.sleep(5000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(500);
	    robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_ENTER);
	// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
	 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
		String invaliddateformatActualExpected =invaliddateformattextvalue;
		Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
	 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
	 Thread.sleep(6000);
	
	     System.out.println("invalid4");
} 

@Test
@Order(6)
public void Template_upload_screen_undefined__for_Multi_Document() throws InterruptedException, AWTException, IOException {
	Thread.sleep(5000);
	 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
	 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
	 Thread.sleep(2000);
	 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
	 Thread.sleep(2000);
	 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
	 Robot robot = new Robot();
	   String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_12    undefined acc multi.xlsx";
	    StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
        Thread.sleep(5000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(500);
	    robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_ENTER);
	// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
	 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
		String invaliddateformatActualExpected =invaliddateformateffectiveexpectedtext;
		Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
	 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
	 Thread.sleep(6000);
	
	     System.out.println("invalid5");
} 
@Test
@Order(7)
public void Template_upload_undefined_productcode__for_Multi_Document() throws InterruptedException, AWTException, IOException {
	Thread.sleep(5000);
	 $(By.xpath(Templateupload)).waitUntil(visible, 30000).click();
	 $(By.xpath("//label[@id='PRIREM__ChargeUpload__el_rdo_1_option_MULTI_span_']")).waitUntil(visible, 40000).click();
	 Thread.sleep(2000);
	 $(By.xpath("//span[@id='PRIREM__ChargeUpload__uploadbt_txtcnt']")).click();
	 Thread.sleep(2000);
	 //$(By.xpath("//input[@id='PRIREM__TemplateUpload__filebrwbt']")).uploadFile(new File("/home/i-exceed.com/udhayakumar.s/Documents/three.xlsx"));
	 Robot robot = new Robot();
	   String path = "/home/i-exceed.com/udhayakumar.s/upload template test case(socgen)automation(feb 3)/Multi/Negative TC/TC_13    undefined product code multi.xlsx";
	    StringSelection stringSelection = new StringSelection(path);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(stringSelection, stringSelection);
        Thread.sleep(5000);
	    robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    Thread.sleep(500);
	    robot.keyPress(KeyEvent.VK_ENTER);
		 robot.keyRelease(KeyEvent.VK_ENTER);
	// $(By.xpath(submitbutton)).waitUntil(visible, 30000).click();
	 String invaliddateformatActual = $(By.xpath("//p[@class='msg']")).waitUntil(visible, 30000).getText();
		String invaliddateformatActualExpected =invaliddateformateffectiveexpectedtext;
		Assertions.assertTrue(invaliddateformatActualExpected.contains((invaliddateformatActual)));
	 $(By.xpath(okbutton)).waitUntil(visible, 30000).click();
	 Thread.sleep(6000);
	
	     System.out.println("invalid6");
} 
}