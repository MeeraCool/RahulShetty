package socgenflow;

import static com.codeborne.selenide.Condition.*;
import org.openqa.selenium.By;

import generic.BaseTest;

import org.junit.jupiter.api.*;

import static com.codeborne.selenide.Selenide.$;

public class Sp2_CommonFunctions extends BaseTest {
	static String Gen_Acc_number;

	public boolean Assert_Icon(String Locator) {
		boolean result = $(By.id(Locator)).waitUntil(visible, 30000).exists();
		return result;
	}

	public void Assert_Text(String Locator, String Expected_value) {
		String Actual_Value = $(By.id(Locator)).waitUntil(visible, 30000).getText();
		Assertions.assertEquals(Expected_value, Actual_Value);
	}

	// Dashboard Navigation
	public void Navigate_to(String Locator) {
		$(By.id(Locator)).waitUntil(visible, 15000).click();
	}

	// Generate Account
	public void Gen_Account(String Status) throws InterruptedException {
		Thread.sleep(3000);
		$(By.id(GenAcc_Button)).waitUntil(visible, 15000).click();
		Thread.sleep(3000);
		$(By.id(GenerateDDA_button)).waitUntil(visible, 15000).click();
		Thread.sleep(3000);
		$(By.id(Status.equals(Status_A) ? Assign_Label : Reserve_Label)).waitUntil(visible, 15000).click();
		$(By.id(Remarks)).sendKeys(Remarks_val);
		Gen_Acc_number = $(By.id(Gen_AccountNumber)).getText();
		Thread.sleep(3000);
		$(By.id(GenAcc_Submit)).waitUntil(visible, 15000).click();
		Thread.sleep(3000);
		if ($(By.id(Gen_Acc_SuccessText)).is(visible)) {
			$(By.id(Success_RM_Button)).waitUntil(visible, 15000).click();
		} else if ($(By.xpath(Error_message)).is(visible)) {
			$(By.xpath(Error_Ok)).waitUntil(visible, 15000).click();
		}}
		public void Gen_Account1(String Status) throws InterruptedException {
			Thread.sleep(3000);
			$(By.id(GenAcc_Button)).waitUntil(visible, 15000).click();
			Thread.sleep(3000);
			$(By.id(GenerateDDA_button)).waitUntil(visible, 15000).click();
			Thread.sleep(3000);  
			$(By.id(GenAcc_Submit)).waitUntil(visible, 15000).click(); 
			$(By.xpath(Accountgen_okbutton)).waitUntil(visible, 15000).click();
			System.out.println("teske1");

	}

	public void Navigate1() throws InterruptedException {
        Thread.sleep(6000);
		$(By.xpath("//a[contains(text(),'Grid')]")).waitUntil(visible, 15000).click();
		System.out.println("teske1");
	}
  
	// CheckGenerated_Account
	public void Check_Generated_Account() {
		$(By.id(Inprogress_Account)).waitUntil(visible, 15000).click();
		$(By.id(GenAcc_SearchField)).waitUntil(visible, 15000).sendKeys(Gen_Acc_number);
		Assertions.assertTrue($(By.id(Check_AccNum)).waitUntil(visible, 15000).getText().equals(Gen_Acc_number));

	}

	// grid creation
	public void Gridcreationcall() throws InterruptedException {
		{

			{
				Thread.sleep(5000);
				$(By.xpath(Gridaddbut)).waitUntil(visible, 15000).click();
				$(By.id(Gridid)).waitUntil(visible, 15000).sendKeys("87656");
				$(By.id(Gridname)).waitUntil(visible, 15000).sendKeys("888888");
				$(By.id(Gridproductbox)).waitUntil(visible, 15000).click();
				$(By.id(Gridproductinput)).waitUntil(visible, 15000).click();
				Thread.sleep(5000);
				$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
				Thread.sleep(5000);
				$(By.xpath(creationviewgrid)).waitUntil(visible, 15000).click();
				$(By.xpath(searchbutton)).waitUntil(visible, 15000).sendKeys("87656");
				Thread.sleep(5000);
				$(By.xpath(searchbutton)).waitUntil(visible, 15000).clear();
				System.out.println("iii");
				Thread.sleep(5000);

			}}
		}
		public void Gridcreationcall1() throws InterruptedException {
			{

				{
					Thread.sleep(20000);
					$(By.xpath(Gridaddbut)).waitUntil(visible, 50000).click();
					$(By.id(Gridid)).waitUntil(visible, 15000).sendKeys("767");
					$(By.id(Gridname)).waitUntil(visible, 15000).sendKeys("888888");
					$(By.id(Gridproductbox)).waitUntil(visible, 15000).click();
					$(By.id(Gridproductinput)).waitUntil(visible, 15000).click();
					Thread.sleep(5000);
					$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
					Thread.sleep(5000);
					$(By.xpath(creationviewgrid)).waitUntil(visible, 15000).click();
					$(By.xpath(searchbutton)).waitUntil(visible, 15000).sendKeys("767");
					Thread.sleep(5000);
					$(By.xpath(searchbutton)).waitUntil(visible, 15000).clear();
					System.out.println("iii");
					Thread.sleep(5000);

				}
			}
	}

	public void Grideditcall() throws InterruptedException {

		System.out.println("strst");
		$(By.xpath(searchbutton)).waitUntil(visible, 15000).sendKeys("87656");
		Thread.sleep(5000);
		$(By.xpath(grideditforwardicon)).waitUntil(visible, 15000).click();
		$(By.id(grideditoption)).waitUntil(visible, 15000).click();

		$(By.id(gridproductbox1)).waitUntil(visible, 15000).click();
		$(By.xpath(gridproductboxvalue1)).waitUntil(visible, 15000).click();
		$(By.xpath(addicon)).waitUntil(visible, 15000).click();
		$(By.xpath(gridproductboxpro)).waitUntil(visible, 15000).click();
		$(By.xpath(gridproductboxvaluepro)).waitUntil(visible, 15000).click();
		$(By.id(grideditsubmit)).waitUntil(visible, 15000).click();
		Thread.sleep(5000);
		$(By.xpath(Editviewgrid)).waitUntil(visible, 15000).click();
		Thread.sleep(5000);
		System.out.println("pppppp");
		System.out.println("stop");

	}
	
	
	public void grid_without_entering_value() throws InterruptedException {
		{

			{
				Thread.sleep(5000);
				$(By.xpath(Gridaddbut)).waitUntil(visible, 15000).click();
				$(By.id(Gridid)).waitUntil(visible, 15000).click();
				$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
				Thread.sleep(2000);
				$(By.xpath(okbutton_gridinvalid)).waitUntil(visible, 15000).click();
				Thread.sleep(2000);
				$(By.id(Gridid)).waitUntil(visible, 15000).sendKeys("767");
				$(By.id(Gridname)).waitUntil(visible, 15000).click();
				$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
				$(By.xpath(okbutton_gridinvalid)).waitUntil(visible, 15000).click();
				$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
				Thread.sleep(2000);
				$(By.xpath(okbutton_gridinvalid)).waitUntil(visible, 15000).click();	
				Thread.sleep(2000);
			}}}
	
	
	
	public void GridID_withexixtingvalues() throws InterruptedException {
		Thread.sleep(5000);
		$(By.xpath(Gridaddbut)).waitUntil(visible, 15000).click();
		$(By.id(Gridid)).waitUntil(visible, 15000).sendKeys("767");
		$(By.xpath(Gridsumbit)).waitUntil(visible, 15000).click();
		$(By.xpath(okbutton_gridinvalid)).waitUntil(visible, 15000).click();
		
		
	}

	// Logout
	public void Logout() {
		$(By.id(Logout_Button)).waitUntil(visible, 15000).click();
		if ($(By.xpath(Error_message)).waitUntil(visible, 5000).is(visible)) {
			$(By.xpath(Error_Ok)).waitUntil(visible, 15000).click();
		}

	}

	protected void Gridcreation() {
		// TODO Auto-generated method stub

	
	
	
	
	
	
	}
}






