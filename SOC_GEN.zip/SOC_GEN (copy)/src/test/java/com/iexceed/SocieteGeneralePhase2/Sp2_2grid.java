package com.iexceed.SocieteGeneralePhase2;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import socgenflow.Sp2_CommonFunctions;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
@TestMethodOrder(OrderAnnotation.class)
public class Sp2_2grid extends Sp2_CommonFunctions{
	@Test
	@DisplayName("Login")
	@Order(1)
	public void Login_Maker() {
		Login(M);
	}
	@Test
	@DisplayName("Menu Navigation")
	@Order(2)
	public void Menu_Navigation() throws InterruptedException {
		Navigate1();
	}
	@Test
	@DisplayName("create grid")
	@Order(3)
	public void Grid_cration() throws InterruptedException {
		Gridcreationcall1();
	}
}