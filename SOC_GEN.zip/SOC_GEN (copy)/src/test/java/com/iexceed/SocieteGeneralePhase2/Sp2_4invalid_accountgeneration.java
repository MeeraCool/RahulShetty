package com.iexceed.SocieteGeneralePhase2;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import socgenflow.Sp2_CommonFunctions;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
@TestMethodOrder(OrderAnnotation.class)
public class Sp2_4invalid_accountgeneration extends Sp2_CommonFunctions{
	@Test
	@DisplayName("Login")
	@Order(1)
	public void Login_Maker() {
		Login(M);
	}
	@Test
	@DisplayName("Menu Navigation")
	@Order(2)
	public void Menu_Navigation() {
		Navigate_to(Accopening_Menu);
	}
	@Test
	@DisplayName("Generate Acccount")
	@Order(3)
	public void Generate_Account_withoutvalues() throws InterruptedException {
		Gen_Account1(Status_val);
	}
	@Test
	@DisplayName("Loging Out Maker")
	@Order(4)
	public void Logout_Maker() {
		Logout();
	}}