package com.iexceed.SocieteGeneralePhase2;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import socgenflow.Sp2_CommonFunctions;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
@TestMethodOrder(OrderAnnotation.class)
public class sp2_5invalid_grid extends Sp2_CommonFunctions{
	@Test
	@DisplayName("Login")
	@Order(1)
	public void Login_Maker() {
		Login(M);
	}
	@Test
	@DisplayName("Menu Navigation")
	@Order(2)
	public void Menu_Navigation() throws InterruptedException {
		Navigate1();
	}
	@Test
	@DisplayName("Grid without values")
	@Order(3)
	public void Grid_withoutvalues() throws InterruptedException {
		grid_without_entering_value();
		
		Navigate1();
	}
	@Test
	@DisplayName("Grid ID with exixting values")
	@Order(4)
	public void Gridid_Existingvalues() throws InterruptedException {
		Gridcreationcall1();
		GridID_withexixtingvalues();

	
}}