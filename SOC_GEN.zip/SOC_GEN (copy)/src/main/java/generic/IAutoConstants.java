package generic;

public interface IAutoConstants {
	// General

	String EXCEL_PATH = "/home/i-exceed.com/udhayakumar.s/Documents/automation/SOC_GEN/Input_Data/socgen.xlsx";
	String SSPATH="./Screenshot_Results/";
	String CONFIG_PATH = "./Property_Files/config.properties";
	String EXCEL_PATH1 = "/home/i-exceed.com/udhayakumar.s/Videos/account generation/SOC_GEN (copy)/socgen1.xlsx";
	String EXCEL_PATH_Sp2="/home/i-exceed.com/udhayakumar.s/Videos/account generation/SOC_GEN (copy)/Input_Data/Input_Data.xlsx";
	                      
	
	//loginExcel_Data.getValue
	String soclogininputbox = Excel_Data.getValue(EXCEL_PATH, "login", 2, 1);
	String socloginval = Excel_Data.getValue(EXCEL_PATH, "login", 2, 3);
	String socpasswordinputbox = Excel_Data.getValue(EXCEL_PATH, "login", 4, 1);
	String socpasswordval = Excel_Data.getValue(EXCEL_PATH, "login", 4, 3);
	String socloginbutton = Excel_Data.getValue(EXCEL_PATH, "login", 5, 1);
	String socpasswordshowicon = Excel_Data.getValue(EXCEL_PATH, "login", 6, 1);
	String socloginval1 = Excel_Data.getValue(EXCEL_PATH, "login", 2, 5);
	String socpasswordval1 = Excel_Data.getValue(EXCEL_PATH, "login", 4, 5);
	
	
	//templateuploadtemplate
	String Templateupload = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 1, 1);
	String singleaccountinputbox = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 2, 1);
	String singleaccountinputboxval = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 2, 3);
	String uploadbutton = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 3, 1);
	String submitbutton = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 4, 1);
	String multiaccount = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 6, 1);
	String multiaccountbutton = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 8, 1);
	String norecordsfoundimage = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 9, 1);
	
	
//successscreen
	String success = Excel_Data.getValue(EXCEL_PATH, "success", 1, 1);
	
	
	
	//pricing screen
	String myrequestsmenu = Excel_Data.getValue(EXCEL_PATH, "pricing", 1, 1);
	String Accountnumbervalue = Excel_Data.getValue(EXCEL_PATH, "pricing", 2, 1);
///	String Accountnumbervalue1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 2, 3);
	String myrequestsforwardicon = Excel_Data.getValue(EXCEL_PATH, "pricing", 3, 1);
	String myrequestsforwardicon1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 5, 1);
	String pricingmain = Excel_Data.getValue(EXCEL_PATH, "pricing", 4, 1);
	String Accountnumbervalue1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 6, 1);
	String Approvebutton = Excel_Data.getValue(EXCEL_PATH, "pricing", 7, 1);
	String cancelbutton = Excel_Data.getValue(EXCEL_PATH, "pricing", 8, 1);
	String multiaccountnovalue = Excel_Data.getValue(EXCEL_PATH, "pricing", 9, 1);
	String multiaccountnovalue1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 9, 3);
	String Accountnumbervaluesearch = Excel_Data.getValue(EXCEL_PATH, "pricing", 10, 1);
	String Accountnumbervaluesearch1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 10, 3);
	String Accountnumbervaluesearchmulti = Excel_Data.getValue(EXCEL_PATH, "pricing", 11, 1);
	String Accountnumbervaluesearchmulti1 = Excel_Data.getValue(EXCEL_PATH, "pricing", 11, 3);
	String multiaccounticon = Excel_Data.getValue(EXCEL_PATH, "pricing", 12, 1);
	
	
//myrequestscreen
	String All = Excel_Data.getValue(EXCEL_PATH, "myrequestsscreen", 1, 1);
	String swiftnet = Excel_Data.getValue(EXCEL_PATH, "myrequestsscreen", 2, 1);
	String downloadtemprequest = Excel_Data.getValue(EXCEL_PATH, "myrequestsscreen", 3, 1);
	String downloadtemprequest1 = Excel_Data.getValue(EXCEL_PATH, "myrequestsscreen", 4, 1);
	String Downloadtemplatemy = Excel_Data.getValue(EXCEL_PATH, "myrequestsscreen", 5, 1);
	
	//myapproval
	String myapprovals = Excel_Data.getValue(EXCEL_PATH, "myapproval", 1, 1);
	
	
	
	
	
	//searchbox
	String searchbox = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 1, 1);
	String searchboxnext = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 2, 1);
	String adminpendingapprovalmain = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 3, 1);
	String norecordsfoundtext = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 4, 1);
	String norecordsfoundtext1 = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 5, 1);
	String murequestsmain = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 6, 1);
	String searchnotfoundimage = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 7, 1);
	String norecordsfoundtextid = Excel_Data.getValue(EXCEL_PATH, "searchvalues", 10, 1);
	//searchnotfoundimage
	//murequestsmain
	//invalidscenrios
  String invaliddateformattextvalue = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 1, 3);
  String okbutton = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 2, 1);
  //String invaliddateformattext = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 1, 1);
  String invaliddateformateffectiveexpectedtext = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 3, 3);
  String invaliddateformatdiffereffectiveexpectedtext = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 4, 3);
  String invalidundefined = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 4, 3);
  String invalidrepative = Excel_Data.getValue(EXCEL_PATH, "invalidvaluessingle", 5, 3);
	
  
  
  
  
  
  
  
  
  
  
  //phase 2
  String singleaccountbox = Excel_Data.getValue(EXCEL_PATH, "phase", 1, 1); 
  String uploadbuttonsinglen = Excel_Data.getValue(EXCEL_PATH, "phase", 2, 1);
  String ACPs = Excel_Data.getValue(EXCEL_PATH, "phase", 3, 1);
  String multiaccounticonbox = Excel_Data.getValue(EXCEL_PATH, "phase", 4, 1);
  String uploadbuttonmultiten = Excel_Data.getValue(EXCEL_PATH, "phase", 5, 1);
  String   CPMm = Excel_Data.getValue(EXCEL_PATH, "phase", 7, 1);
	
  
  //Account opening reconciliation
  String Accountpricingreconciliation = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 9, 1);
  String submitbutton1 = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 7, 1);
  String cancelbutton1 = Excel_Data.getValue(EXCEL_PATH, "Templateupload", 8, 1);
    
  
  //RMDashboard
  String RMDashboardforwardicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 1, 1);
  String DDAaccountnumber = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 2, 1);
  String viewicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 3, 1);
  //--Activity statement
  String Actitvitystatementbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 4, 1);
  String Asfromdateinput = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 5, 1);
  String Asoneicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 6, 1);
  String Astodateinput = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 7, 1);
  String Astwoicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 8, 1);
  String Searchbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 9, 1);
  String Asforwardicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 10, 1);
  String moredeatilsheading = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 11, 1);
  String intoOption = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 12, 1);
  String Asbackicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 13, 1);
  //--invoice
  String Invoicebutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 15, 1);
  String invoicelabel = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 16, 1);
  String billingperiod  = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 17, 1);
  String billingperoidmonth = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 18, 1);
  String searchbuttoninvoice = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 19, 1);
  String invoiceback = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 20, 1);
  //--chargepricing
  String chargepricingbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 22, 1);
  String chargepricinglabel = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 23, 1);
  String chargepricingback = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 24, 1);
  //--interestpricing
  String interestpricingbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 26, 1);
  String interestpricinglabel = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 27, 1);
  String interestpricingback = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 28, 1);
  
  //--balanceternd
  String balancetrendbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 30, 1);
  String balancetrendlabel = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 31, 1);
  String balancetrendback = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 32, 1);
  
 
  
  
  //--- billingtrend
  String billingtrendbutton = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 34, 1);
  String billingtrendfromdate = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 35, 1);
  String btoneicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 36, 1);
  String bttodate = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 37, 1);
  String bttwoicon = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 38, 1);
  String billingtrendback = Excel_Data.getValue(EXCEL_PATH, "RMDashboard", 39, 1);
  
  
  //socgen phase2
  
 // String  = Excel_Data.getValue(EXCEL_PATH, "logout", 3, 1);

  
  
  
  
  
  
  
  
  
  
  //logout function
  String logouticon = Excel_Data.getValue(EXCEL_PATH, "logout", 1, 1);
  String logouttextvalue = Excel_Data.getValue(EXCEL_PATH, "logout", 2, 1);
  String logouttextvalueexpect = Excel_Data.getValue(EXCEL_PATH, "logout", 2, 3);
  String logoutok = Excel_Data.getValue(EXCEL_PATH, "logout", 3, 1);
  String logoutcancel = Excel_Data.getValue(EXCEL_PATH, "logout", 4, 1);

  
  //socgen phase2
  //interest_singletemplateupload
  String Interest_templateupload = Excel_Data.getValue(EXCEL_PATH1, "phase2", 10, 1);
  String Interest_singleinputbox= Excel_Data.getValue(EXCEL_PATH1, "phase2", 11, 1);
  String Interest_uploadbutton = Excel_Data.getValue(EXCEL_PATH1, "phase2", 12, 1);
  String Interest_singleACP = Excel_Data.getValue(EXCEL_PATH1, "phase2", 13, 1);
  String Interest_singledownloadtemplate = Excel_Data.getValue(EXCEL_PATH1, "phase2",14, 1);
  String Interest_singleCE = Excel_Data.getValue(EXCEL_PATH1, "phase2", 15, 1);
  String Interest_singlemyrequesticon = Excel_Data.getValue(EXCEL_PATH1, "phase2", 16, 1);

  
  
  //interest_singletemplateupload_adminL
  String Interest_singledownAdmin_Myreq_CE= Excel_Data.getValue(EXCEL_PATH1, "phase2",18, 1);
  String Interest_singledownAdmin_Myapp_CE1 = Excel_Data.getValue(EXCEL_PATH1, "phase2",19, 1);
//interest_multitemplateupload
  String Interest_templateuploadmulti = Excel_Data.getValue(EXCEL_PATH1, "phase2", 23, 1);
  String Interest_siinputbox= Excel_Data.getValue(EXCEL_PATH1, "phase2", 24, 1);
  String Interest_uploadbuttonmulti = Excel_Data.getValue(EXCEL_PATH1, "phase2", 25, 1);
  String Interest_multiACP = Excel_Data.getValue(EXCEL_PATH1, "phase2", 26, 1);
  String Interest_multidownloadtemplate = Excel_Data.getValue(EXCEL_PATH1, "phase2",27, 1);
  String Interest_multiCE = Excel_Data.getValue(EXCEL_PATH1, "phase2", 28, 1);
  String Interest_multimyrequesticon = Excel_Data.getValue(EXCEL_PATH1, "phase2", 29 , 1);
  
  //interest_multitemplateupload_adminP
  String Interest_multiicon = Excel_Data.getValue(EXCEL_PATH1, "phase2", 32, 1);
  String Interest_multiicon1 = Excel_Data.getValue(EXCEL_PATH1, "phase2", 33 , 1);
  String Interest_multidownAdmin_Myreq_CE= Excel_Data.getValue(EXCEL_PATH1, "phase2",34, 1);
  String Interest_multidownAdmin_Myapp_CE1 = Excel_Data.getValue(EXCEL_PATH1, "phase2",35, 1);
  
//invalidsingle q
  String single_okbutton= Excel_Data.getValue(EXCEL_PATH1, "phase2", 11, 1);
  String sin_msgpop= Excel_Data.getValue(EXCEL_PATH1, "phase2", 11, 1);
  
  String chargesingleinput = Excel_Data.getValue(EXCEL_PATH1, "phase2", 1, 1);
  String chargeupload = Excel_Data.getValue(EXCEL_PATH1, "phase2", 2, 1);
  String charge_ACP = Excel_Data.getValue(EXCEL_PATH1, "phase2", 3, 1);
  
  
  
  //multi__c
  String Charge_multiinputbox = Excel_Data.getValue(EXCEL_PATH1, "phase2", 46, 1);
  String Charge_multiuploadbutton = Excel_Data.getValue(EXCEL_PATH1, "phase2", 47, 1);
  String Charge_multiACP = Excel_Data.getValue(EXCEL_PATH1, "phase2", 48, 1);
  String Charge_multiMyrequestmainalbel = Excel_Data.getValue(EXCEL_PATH1, "phase2", 49, 1);
 // String Interesttemplateupload = Excel_Data.getValue(EXCEL_PATH1, "phase2", 9, 1);
  //String  = Excel_Data.getValue(EXCEL_PATH, "phase2", 4, 2);
  
  
  //negative flow
  String Interesttemplateupload = Excel_Data.getValue(EXCEL_PATH1, "phase2", 9, 1);
  String interestsingleinputbox = Excel_Data.getValue(EXCEL_PATH1, "phase2", 10, 1);
  String interestuploadbutton = Excel_Data.getValue(EXCEL_PATH1, "phase2", 11, 1);
  String interest1 = Excel_Data.getValue(EXCEL_PATH1, "phase2", 12, 1);
  String interest2 = Excel_Data.getValue(EXCEL_PATH1, "phase2", 13, 1);
  String interest3 = Excel_Data.getValue(EXCEL_PATH1, "phase2", 14, 1);
  //String interest4 = Excel_Data.getValue(EXCEL_PATH1, "phase2", 1, 1);
  //String chargesingleinput = Excel_Data.getValue(EXCEL_PATH1, "phase2", 1, 1);
  String K_myrequestforwardicon = Excel_Data.getValue(EXCEL_PATH1, "phase2", 36, 1);
  
  //socgen2
 

 
  	
  	
  	
  	//Roles
  	final String M="maker";
  	final String C="checker";
  	//Acc-Status
  	final String Status_A="ASSIGN";
  	final String Status_R="RESERVE";
  	
  	//Login
  	String Username=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 1,2);
  	String Password=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 2,2);
  	String Login_Button=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 3,2);
  	String SocGen_Logo=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 4,2);
  	
  	//Login
  	String Username_val_Maker=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",1,3);
  	String Password_val_Maker=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",2,3);
  	String Username_val_Checker=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",1,4);
  	String Password_val_Checker=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",2,4);
  	//grid
  	String Gridmain=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",1,2);
  	String Gridaddbut=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",2,2);
  	String Gridid=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",3,2);
  	String Gridname=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",4,2);
  	String Gridproductbox=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",5,2);
      String Gridproductinput=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",6,2);
  	String Gridsumbit=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",7,2);
  	String creationviewgrid=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",8,2);
  	String searchbutton=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",9,2);
  	String searchbuttonvalue=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",9,3);
      //edit grid
     String grideditforwardicon=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",10,2);
     String grideditoption=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",11,2);
     String gridproductbox1=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",12,2);
     String gridproductboxvalue1=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",13,2);
     String addicon=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",14,2);
     String gridproductboxpro=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",15,2);
     String gridproductboxvaluepro=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",16,2);
     String grideditsubmit=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",17,2);
     
     
     
     
        
  	
  	
  	//Menu-Dashboard
  	String Accopening_Menu=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 5,2);
  	String Editviewgrid =Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid",18,2);
  		
  	
  	
  	
  	//Generate Account
  	String Processed_Account=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",6,2);
  	String Inprogress_Account=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",7,2);
  	String GenAcc_SearchField=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 8,2);
  	String GenAcc_Button=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",9,2);
  	String GenerateDDA_button=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",10,2);
  	String Assign_Label=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",11,2);
  	String Reserve_Label=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",12,2);
  	String Remarks=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",13,2);
  	String GenAcc_Cancel=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",14,2);
  	String GenAcc_Submit=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",15,2);
  	String Gen_Acc_SuccessText=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",19,2);
  	
  	String Check_AccNum=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",20,2);
  	String Check_generatedby=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",21,2);
  	String Check_AccountStatus=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",22,2);
  	String Check_Remarks=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",23,2);
  	
  	String Gen_AccountNumber=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",24,2);
  	
  	String Success_RM_Button=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",25,2);
  	String Logout_Button=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",26,2);
  	
  	
  	//Generate Account Value
  	String GenAcc_SearchField_val=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 8,3);
  	String Remarks_val=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",13,3);
  	String Status_val=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",11,3);
  	//Error Messages
  	String Error_message=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 16,2);
  	String Error_Ok=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",17,2);
  	String Error_Cancel=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation",18,2);
  	
  //negative account generation flow
  	String Accountgen_okbutton=Excel_Data.getValue(EXCEL_PATH_Sp2, "Account_Generation", 30,2);
  	
  	//negative grid flow
  	String okbutton_gridinvalid=Excel_Data.getValue(EXCEL_PATH_Sp2, "Grid", 28,2);
  }
