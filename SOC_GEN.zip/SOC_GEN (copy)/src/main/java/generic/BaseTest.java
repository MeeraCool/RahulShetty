package generic;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.close;
import static com.codeborne.selenide.Selenide.open;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;


public class BaseTest extends Excel_Data {
	@BeforeAll
	public static void init() {

		close();
		Configuration.browser = "chrome";
		Configuration.startMaximized = true;
		open("http://10.32.2.51:8483/SocieteGenerale/");
		
	}
	@AfterAll
	public static void CloseChrome() {
		WebDriver CurrentDriver = WebDriverRunner.getWebDriver();
		CurrentDriver.quit();
	}
	public void Login(String Role) {
		$(By.id(Username)).waitUntil(visible,15000).sendKeys(Role.equals(M)? Username_val_Maker : Username_val_Checker) ;
		$(By.id(Password)).waitUntil(visible,15000).sendKeys(Role.equals(M)? Password_val_Maker : Password_val_Checker) ;
		$(By.id(Login_Button)).click();
		}
}
